# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 20:38:14 2024

This program  does two things:
    1. Aligns a base bone CoM and principal inertia axes with the global xyz
    2. Rigidly registers the remaining stl files in a directory to the base

@author: jr
"""

# import sys
import os
import numpy as np
import pandas as pd
import trimesh as tri
import meshtools as mt

# Perform registration of one long bone on another by independent
# registration of the two ends. This brings robustness to the process
# because the ends are easier to distinguish than the entire bone.
def rigid_end_registration(Bb,Bt,mirror=False):

    # First, get the target aligned with the coordinate system
    A = Bt.principal_inertia_transform
    Bt.apply_transform(A)
    A = tri.transformations.translation_matrix(-Bt.center_mass)
    Bt.apply_transform(A)
        
    # Mirror if necessary
    if mirror:
        print('Mirrorring')
        mirror_x = np.array([
            [-1,  0,  0,  0],
            [ 0,  1,  0,  0],
            [ 0,  0,  1,  0],
            [ 0,  0,  0,  1]
        ])
        
        # Apply the mirroring transformation to the mesh
        Bt.apply_transform(mirror_x)
        
    # Split the two meshes into halves along the long axis,
    # which should be the z axis after the initial alignment
    Bbprox, Bbdist = mt.splitmesh(Bb)
    Bt1, Bt2 = mt.splitmesh(Bt)

    # The proximal part with the femoral head will have larger principal inertia than
    # the distal part abput the z axis. This way, we can figure out how Bt is oriented
    if Bt1.principal_inertia_components[2]/Bt1.mass > Bt2.principal_inertia_components[2]/Bt2.mass:
        Btprox = Bt1
        Btdist = Bt2
    else:
        flip = np.array([
            [1, 0, 0, 0],
            [0, -1, 0, 0],
            [0, 0, -1, 0],
            [0, 0, 0, 1]])
        Bt.apply_transform(flip)      
        Btprox = Bt2
        Btdist = Bt1
        Btprox.apply_transform(flip)
        Btdist.apply_transform(flip)
        
    # Now, register the procimal and distal ends to Bb and decompose the
    # tranformation matrices to rigid and soft parts
    # Aprox = tri.registration.icp(Btprox.vertices, Bbprox)
    Aprox = tri.registration.mesh_other(Btprox, Bbprox, scale=True, icp_first=50)
    AproxRig, AproxSoft = mt.decompose_affine_transformation(Aprox[0])
    print('AproxRig')
    print(AproxRig)

    Adist = tri.registration.icp(Btdist.vertices, Bbdist, scale=True, initial=Aprox[0])
    AdistRig, AdistSoft = mt.decompose_affine_transformation(Adist[0])
    print('AdistRig')
    print(AdistRig)
    
    # Average the rigid part of the two transformation matrices and move the target
    # bone ends into position
    Apre = mt.interpolate_affine_matrices(AproxRig, AdistRig, 0.5)
    # Btprox.apply_transform(Apre)
    # Btdist.apply_transform(Apre)
    Bt.apply_transform(Apre)
    print('Apre')
    print(Apre)
    
    # Now, the two bones should be rigidly aligned, and we can apply
    # the non-rigid (soft) part of the transformation to the ends
    Btprox.apply_transform(Aprox[0])
    Btdist.apply_transform(Adist[0])

    Btprox.visual.vertex_colors = mt.randomcolor()
    Btdist.visual.vertex_colors = mt.randomcolor()
    Btprox.export('Femurs/Btproxreg.obj')
    Btdist.export('Femurs/Btdistreg.obj')
    
    AproxInv = mt.inverse_affine_transformation(Aprox[0])
    AdistInv = mt.inverse_affine_transformation(Adist[0])
    diff1 = Aprox[-1]
    diff2 = Adist[-1]
    
    return(AproxInv, AdistInv, diff1, diff2, Bt)

"""
This function scans the folder directory/Femurs/stl for stl files containing femurs.
It then processes those that are not already saved as .obj files. The processing
is a rigid registration to the base mesh stored in base.obj. The registered
meshes are assigned a random color and stored as obj files
"""
def filelist(directory,base):

    stlfiles = set()
    objfiles = set()
    for filename in os.listdir(directory+'/stl'):
        if filename.endswith('.stl'):
            stlfiles.add(filename[:-4])
    for filename in os.listdir(directory):
        if filename.endswith('.obj'):
            objfiles.add(filename[:-4])

    return list(stlfiles-objfiles)

# Inventory
directory = 'C:/Users/jr/Documents/GitHub/Registration/Femurs'
base = 'tlem2'
baseside = 'R'

stls = filelist(directory,base)
        
# Read existing list of femurs
femurs = pd.read_excel(directory+'/femurs.xlsx',index_col=0)

# Select base bone and align it
Bb = tri.load_mesh(directory+'/stl/'+base+'.stl')
A = Bb.principal_inertia_transform
Bb.apply_transform(A)
A = tri.transformations.translation_matrix(-Bb.center_mass)
Bb.apply_transform(A)
Bb.visual.vertex_colors = mt.randomcolor()

Bb1, Bb2 = mt.splitmesh(Bb)

# The proximal part with the femoral head will have larger principal inertia than
# the distal part abput the z axis. This way, we can figure out how Bt is oriented
if Bb1.principal_inertia_components[2]/Bb1.mass < Bb2.principal_inertia_components[2]/Bb2.mass:
    flip = np.array([
        [1, 0, 0, 0],
        [0, -1, 0, 0],
        [0, 0, -1, 0],
        [0, 0, 0, 1]])
    Bb.apply_transform(flip)      

Bb.export(directory+'/'+base+'.obj')

for bone in stls:
    print('processing '+bone)
    
    if bone == base:
        continue
    
    Bt = tri.load_mesh(directory+'/stl/'+bone+'.stl')
    
    mirror = False
    if femurs.loc[bone,'Side'] != baseside:
        mirror = True
    
    A1inv, A2inv, diff1, diff2, Btrigid = rigid_end_registration(Bb, Bt, mirror)

    # Assign color and export
    mt.savemesh(Btrigid, directory+'/'+bone+'.obj')
