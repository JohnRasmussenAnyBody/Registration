# -*- coding: utf-8 -*-
"""
Created on Mon Aug 26 13:49:41 2024

This program reads precomputed affine mapping parameters and applies them
to check the algorithm.

@author: jr
"""

import numpy as np
import pandas as pd
import trimesh as tri
import meshtools as mt

directory = 'C:/Users/jr/Documents/GitHub/Registration/Femurs'
base = 'tlem2'
baseside = 'R'

# Load base bone
Bb = tri.load_mesh(directory+'/'+base+'.obj')
minz = Bb.bounds[0,2]
maxz = Bb.bounds[1,2]
lz = maxz-minz

# Read existing list of femurs
femurs = pd.read_excel('Femurs/femurs.xlsx',index_col=0)

for bone in femurs.index:
    
    print(bone)
    
    if bone==base:
        continue
    
    row = femurs.loc[bone]

    # Form proximal matrix
    params = row.iloc[5:17]
    scaling = np.array(params[0:3])
    rotation_vector = np.array(params[3:6])
    shearing_vector = np.array(params[6:9])
    translation = np.array(params[9:12])
    Aprox = mt.recompose_affine_matrix(scaling, rotation_vector, shearing_vector, translation)
    
    # Form distal matrix
    params = row.iloc[17:29]
    scaling = np.array(params[0:3])
    rotation_vector = np.array(params[3:6])
    shearing_vector = np.array(params[6:9])
    translation = np.array(params[9:12])
    Adist = mt.recompose_affine_matrix(scaling, rotation_vector, shearing_vector, translation)
    
    # Perform an interpolated mapping between the two ends
    vertices = Bb.vertices
    transformed_vertices = np.zeros_like(vertices)

    # Loop over each vertex
    for i, vertex in enumerate(vertices):
        # Convert the vertex to homogeneous coordinates
        vertex_homogeneous = np.append(vertex, 1)
        alpha = (vertex[2]-minz)/lz
        A = mt.interpolate_affine_matrices(Adist, Aprox, alpha)
        
        # Transform the vertex using the modified matrix
        transformed_vertex_homogeneous = A @ vertex_homogeneous
        
        # Convert back to 3D coordinates
        transformed_vertices[i] = transformed_vertex_homogeneous[:3]

    # Create a new mesh with the transformed vertices and the same faces
    Bbtrans = tri.Trimesh(vertices=transformed_vertices, faces=Bb.faces)
    mt.savemesh(Bbtrans, directory+'/Maps/'+base+'_'+bone+'.obj')
    