# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 20:38:14 2024

This program attempts to map a source bone to a target bone

@author: jr
"""

# import sys
import os
import numpy as np
import pandas as pd
import trimesh as tri
import meshtools as mt

# Perform registration of one long bone on another by independent
# registration of the two ends. This will allow a subsequent interpolated
# mapping between the bones that allows for bends and twists.
# The base mesh must be aligned with the z axis with the proximal
# end at the top.
def end_registration(Bb,Bt):
        
    # Split the two meshes into halves along the long axis,
    # which should be the z axis after the initial alignment
    Bbprox, Bbdist = mt.splitmesh(Bb, 0.33, True)
    Btprox, Btdist = mt.splitmesh(Bt, 0.33, True)
        
    # Now, register the proximal end to Bt on a node-by-node
    # basis to create a target with the same node structure as the base
    transprox = Btprox.center_mass-Bbprox.center_mass
    Bbprox.apply_translation(transprox)
    A = tri.registration.icp(Bbprox.vertices, Btprox, scale=True)
    Bbprox.apply_transform(A[0])
    vertices = tri.registration.nricp_amberg(Bbprox, Btprox)
    faces = Bbprox.faces
    print('Amberg proximal done')
    
    assert vertices.shape[0] == Bbprox.vertices.shape[0], "The number of vertices in res must match the original mesh"
    
    # Create a new target mesh with the same vertex structure as Bb
    Bbt = tri.Trimesh(vertices=vertices, faces=faces, process=False)
    result = mt.optimize_affine_transformation(Bbprox, Bbt)
    Aopt = mt.recompose_affine_matrix(result.x[0:3], result.x[3:6], result.x[6:9], result.x[9:12]+transprox)
    ProxResults = Aopt @ A[0]  # The initial movement from icp must be included

    # Same for the distal end
    transdist = Btdist.center_mass-Bbdist.center_mass
    Bbdist.apply_translation(transdist)
    A = tri.registration.icp(Bbdist.vertices, Btdist, scale=True)
    Bbdist.apply_transform(A[0])
    vertices = tri.registration.nricp_amberg(Bbdist, Btdist)
    faces = Bbdist.faces
    print('Amberg distal done')
    
    assert vertices.shape[0] == Bbdist.vertices.shape[0], "The number of vertices in res must match the original mesh"
    
    # Create a new target mesh with the same vertex structure as Bb
    Bbt = tri.Trimesh(vertices=vertices, faces=faces, process=False)
    result = mt.optimize_affine_transformation(Bbdist, Bbt)
    Aopt = mt.recompose_affine_matrix(result.x[0:3], result.x[3:6], result.x[6:9], result.x[9:12]+transdist)
    DistResults = Aopt @ A[0]
    
    return(ProxResults, DistResults)

# Inventory
directory = 'C:/Users/jr/Documents/GitHub/Registration/Femurs'
base = 'tlem2'
baseside = 'R'

# Load base bone
Bb = tri.load_mesh(directory+'/'+base+'.obj')

# Inventory of obj files to register
objfiles = set()
for filename in os.listdir(directory):
    if filename.endswith('.obj'):
        objfiles.add(filename[:-4])
        
objfiles = objfiles - set(base)
        
# Read existing list of femurs
femurs = pd.read_excel('Femurs/femurs.xlsx',index_col=0)

for bone in objfiles:
    print('processing '+bone)
    
    if not '1517L' in bone:
        continue

    # Skip random obj files that we have accumulated   
    if not 'Femur' in bone:
        continue
    
    # if bone.split('.')[0] != '588R_Femur':
    #     continue
    
    Bt = tri.load_mesh(directory+'/'+bone+'.obj')
    
    mirror = False
    if femurs.loc[bone,'Side'] != baseside:
        mirror = True
    
    A1, A2 = end_registration(Bb, Bt)
    scale1, rot1, shear1, trans1 = mt.decompose_affine_matrix(A1)
    res1 = np.concatenate([scale1, rot1, shear1, trans1])
    scale2, rot2, shear2, trans2 = mt.decompose_affine_matrix(A2)
    res2 = np.concatenate([scale2, rot2, shear2, trans2])

    # We save only the non-rigid parts of the transformation    
    for i in range(12):
        femurs.loc[bone,'Prox'+str(i)] = res1[i]
    for i in range(12):
        femurs.loc[bone,'Dist'+str(i)] = res2[i]

femurs.to_excel('Femurs/femurs.xlsx')
