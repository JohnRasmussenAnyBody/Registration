# -*- coding: utf-8 -*-
"""
Created on Fri Aug 23 15:12:10 2024

Tools for mesh manipulation

@author: jr
"""
import numpy as np
from scipy.linalg import polar
from scipy.spatial.transform import Rotation as R
from scipy.linalg import logm, expm, svd
from scipy.optimize import minimize
import trimesh as tri

def randomcolor():
    color = (np.random.rand(3)*255).astype(int)
    np.append(color,255)  # Use opague color
    return color

# Given a 4x4 affine transformation matrix A, this function returns the 
# inverse transformation matrix
def inverse_affine_transformation(A):
    # Separate the linear part (top-left 3x3) and the translation part (top-right 3x1)
    M = A[:3, :3]
    t = A[:3, 3]
    
    # Compute the inverse of the linear part
    M_inv = np.linalg.inv(M)
    
    # Compute the inverse translation
    t_inv = -np.dot(M_inv, t)
    
    # Construct the inverse affine transformation matrix
    A_inv = np.eye(4)
    A_inv[:3, :3] = M_inv
    A_inv[:3, 3] = t_inv
    
    return A_inv

"""
Extract the rigid transformation (rotation and translation) from an affine transformation matrix.

Parameters:
A (numpy.ndarray): 4x4 affine transformation matrix.

Returns:
numpy.ndarray: 4x4 rigid transformation matrix.
"""
def extract_rigid_transformation(A):

    # Extract the upper-left 3x3 submatrix (rotation + scaling/shearing)
    M = A[:3, :3]
    
    # Use SVD to extract the closest orthogonal matrix (rotation matrix)
    U, _, Vt = np.linalg.svd(M)
    R = np.dot(U, Vt)
    
    # Extract the translation vector
    t = A[:3, 3]
    
    # Construct the rigid transformation matrix
    rigid_transformation = np.eye(4)
    rigid_transformation[:3, :3] = R
    rigid_transformation[:3, 3] = t
    
    return rigid_transformation

"""
Decompose an affine transformation matrix into rigid and non-rigid components.

Parameters:
A (numpy.ndarray): 4x4 affine transformation matrix.

Returns:
numpy.ndarray: 4x4 rigid transformation matrix (rotation + translation).
numpy.ndarray: 4x4 non-rigid transformation matrix (scaling + shearing).
"""
def decompose_affine_transformation(A):
    # Extract the upper-left 3x3 submatrix (rotation + scaling/shearing)
    M = A[:3, :3]
    
    # Use SVD to decompose M into U, S, and Vt
    U, S, Vt = np.linalg.svd(M)
    
    # The rigid transformation (rotation)
    R = np.dot(U, Vt)
    
    # The non-rigid transformation (scaling + shearing)
    N = np.dot(np.linalg.inv(R), M)
    
    # Extract the translation vector
    t = A[:3, 3]
    
    # Construct the rigid transformation matrix
    rigid_transformation = np.eye(4)
    rigid_transformation[:3, :3] = R
    rigid_transformation[:3, 3] = t
    
    # Construct the non-rigid transformation matrix
    non_rigid_transformation = np.eye(4)
    non_rigid_transformation[:3, :3] = N
    
    return rigid_transformation, non_rigid_transformation

def normalize_rotation_vector(rotvec):
    """
    Normalize the rotation vector to ensure the rotation angle is in [0, pi].
    If the angle is greater than pi, convert it to 2*pi - angle and flip the axis.
    
    Parameters:
    rotvec (numpy.ndarray): Rotation vector.
    
    Returns:
    numpy.ndarray: Normalized rotation vector.
    """
    angle = np.linalg.norm(rotvec)
    if angle > np.pi:
        rotvec = (2 * np.pi - angle) * (-rotvec / angle)
    return rotvec

def consistent_rotation_vector(rotvec1, rotvec2):
    """
    Ensure that two rotation vectors are consistent in direction for interpolation.
    
    Parameters:
    rotvec1 (numpy.ndarray): First rotation vector.
    rotvec2 (numpy.ndarray): Second rotation vector.
    
    Returns:
    numpy.ndarray: The adjusted second rotation vector.
    """
    rotvec2 = normalize_rotation_vector(rotvec2)
    if np.dot(rotvec1, rotvec2) < 0:
        rotvec2 = -rotvec2  # Flip the second rotation vector to align with the first
    return rotvec2

def interpolate_rotation_vectors(rotvec1, rotvec2, alpha):
    """
    Interpolate between two rotation vectors with consistency.
    
    Parameters:
    rotvec1 (numpy.ndarray): First rotation vector.
    rotvec2 (numpy.ndarray): Second rotation vector.
    alpha (float): Interpolation parameter between 0 and 1.
    
    Returns:
    numpy.ndarray: Interpolated rotation vector.
    """
    # Normalize and ensure consistency in the rotation vector direction
    rotvec1 = normalize_rotation_vector(rotvec1)
    rotvec2 = consistent_rotation_vector(rotvec1, rotvec2)
    
    # Interpolate between the rotation vectors
    return (1 - alpha) * rotvec1 + alpha * rotvec2

def decompose_affine_matrix(A):
    """
    Decomposes a 4x4 affine transformation matrix into its scaling, rotation (as a vector),
    shearing (as a vector), and translation components.
    
    Parameters:
    A (numpy.ndarray): 4x4 affine transformation matrix.
    
    Returns:
    tuple: (scaling, rotation_vector, shearing_vector, translation)
    """
    # Extract the translation component
    translation = A[:3, 3]
    
    # Extract the linear transformation matrix
    linear_part = A[:3, :3]
    
    # Perform polar decomposition to separate rotation and shearing
    rotation_matrix, upper_triangular_matrix = polar(linear_part)
    
    # Convert the rotation matrix to a rotation vector (axis-angle representation)
    rotation_vector = R.from_matrix(rotation_matrix).as_rotvec()
    
    # Shearing can be represented by a vector of three independent parameters
    shear_xy = upper_triangular_matrix[0, 1] / upper_triangular_matrix[1, 1]
    shear_xz = upper_triangular_matrix[0, 2] / upper_triangular_matrix[2, 2]
    shear_yz = upper_triangular_matrix[1, 2] / upper_triangular_matrix[2, 2]
    shearing_vector = np.array([shear_xy, shear_xz, shear_yz])
    
    # Scaling factors are the diagonal elements of the upper triangular matrix
    scaling_factors = np.diag(upper_triangular_matrix)
    
    return scaling_factors, rotation_vector, shearing_vector, translation

def decompose_affine_matrix_svd(A):
    """
    Decomposes a 4x4 affine transformation matrix into its scaling, rotation (as a vector),
    shearing (as a vector), and translation components using SVD for improved stability.
    """
    # Extract the translation component
    translation = A[:3, 3]

    # Extract the linear transformation matrix
    linear_part = A[:3, :3]

    # Perform SVD to separate scaling and rotation
    U, S, Vt = svd(linear_part)
    rotation_matrix = np.dot(U, Vt)
    scaling_factors = S

    # Calculate shearing component (residual part after removing rotation and scaling)
    shear_matrix = np.dot(U.T, linear_part) - np.diag(S)
    shearing_vector = np.array([shear_matrix[0, 1], shear_matrix[0, 2], shear_matrix[1, 2]])

    # Convert the rotation matrix to a rotation vector (axis-angle representation)
    rotation_vector = R.from_matrix(rotation_matrix).as_rotvec()

    return scaling_factors, rotation_vector, shearing_vector, translation


def recompose_affine_matrix(scaling, rotation_vector, shearing_vector, translation):
    """
    Recombines scaling, rotation (from a vector), shearing (from a vector), and translation into a 4x4 affine matrix.
    
    Parameters:
    scaling (numpy.ndarray): Scaling factors (3x1 vector).
    rotation_vector (numpy.ndarray): Rotation vector (3x1 vector).
    shearing_vector (numpy.ndarray): Shearing vector (3x1 vector).
    translation (numpy.ndarray): Translation vector (3x1).
    
    Returns:
    numpy.ndarray: 4x4 affine transformation matrix.
    """
    # Convert the rotation vector back to a rotation matrix
    rotation_matrix = R.from_rotvec(rotation_vector).as_matrix()
    
    # Recreate the shearing matrix
    shearing_matrix = np.eye(3)
    shearing_matrix[0, 1] = shearing_vector[0] * scaling[1]
    shearing_matrix[0, 2] = shearing_vector[1] * scaling[2]
    shearing_matrix[1, 2] = shearing_vector[2] * scaling[2]
    
    # Recreate the linear part by combining scaling, rotation, and shearing
    linear_part = np.dot(rotation_matrix, np.dot(np.diag(scaling), shearing_matrix))
    
    # Create the full 4x4 affine transformation matrix
    affine_matrix = np.eye(4)
    affine_matrix[:3, :3] = linear_part
    affine_matrix[:3, 3] = translation
    
    return affine_matrix

def interpolate_affine_matrices(A1, A2, alpha):
    """
    Interpolates between two 4x4 affine transformation matrices.
    
    Parameters:
    A1, A2 (numpy.ndarray): 4x4 affine transformation matrices.
    alpha (float): Interpolation parameter between 0 and 1.
    
    Returns:
    numpy.ndarray: 4x4 interpolated affine transformation matrix.
    """
    # Decompose both matrices into scaling, rotation (as a vector), shearing (as a vector), and translation
    scaling1, rotation_vector1, shearing_vector1, translation1 = decompose_affine_matrix(A1)
    scaling2, rotation_vector2, shearing_vector2, translation2 = decompose_affine_matrix(A2)
    
    # Interpolate the translation component
    translation_interp = (1 - alpha) * translation1 + alpha * translation2
    
    # Interpolate the scaling component
    scaling_interp = (1 - alpha) * scaling1 + alpha * scaling2
    
    # Interpolate the shearing component
    shearing_interp = (1 - alpha) * shearing_vector1 + alpha * shearing_vector2
    
    # Interpolate the rotation vector with normalization and consistency
    rotation_vector_interp = interpolate_rotation_vectors(rotation_vector1, rotation_vector2, alpha)
    
    # Recombine the components into a full affine matrix
    A_interp = recompose_affine_matrix(scaling_interp, rotation_vector_interp, shearing_interp, translation_interp)
    
    return A_interp

"""
Average two rotation matrices using SVD.

Parameters:
R1, R2 (numpy.ndarray): 3x3 rotation matrices.

Returns:
numpy.ndarray: 3x3 average rotation matrix.
"""
def average_rotations(R1, R2):
    # Compute the rotation matrix using SVD on the sum of the rotation matrices
    R = R1 + R2
    U, _, Vt = np.linalg.svd(R)
    R_avg = np.dot(U, Vt)
    
    return R_avg

"""
Compute an average of two affine transformation matrices.

Parameters:
A1, A2 (numpy.ndarray): 4x4 affine transformation matrices.

Returns:
numpy.ndarray: 4x4 average affine transformation matrix.
"""
def average_affine_transformations(A1, A2):
    # Extract the rotation and translation components
    R1 = A1[:3, :3]
    R2 = A2[:3, :3]
    t1 = A1[:3, 3]
    t2 = A2[:3, 3]
    
    # Average the translation components
    t_avg = (t1 + t2) / 2.0
    
    # Average the rotation matrices using SVD
    R_avg = average_rotations(R1, R2)
    
    # Construct the average affine transformation matrix
    A_avg = np.eye(4)
    A_avg[:3, :3] = R_avg
    A_avg[:3, 3] = t_avg
    
    return A_avg

"""
Logarithmic interpolation between two affine transformation matrices 
using matrix logarithm and exponential. The algorithm takes the
logarithms of two transformation matrices before interpolation.
This tends to make nonlinear properties linear and will create
a better interpolation.

Parameters:
A1, A2 (numpy.ndarray): 4x4 affine transformation matrices.
alpha (float): Interpolation factor between 0 and 1.

Returns:
numpy.ndarray: 4x4 interpolated affine transformation matrix.
"""
def logarithmic_interpolation(A1, A2, alpha):
    # Compute the matrix logarithms of the transformation matrices
    log_A1 = logm(A1)
    log_A2 = logm(A2)
    
    # Interpolate in the logarithmic space
    log_A_interp = (1 - alpha) * log_A1 + alpha * log_A2
    
    # Compute the matrix exponential of the interpolated matrix
    A_interp = expm(log_A_interp)
    
    return A_interp

def safe_logarithmic_interpolation(A1, A2, alpha):
    """
    Interpolates between two affine transformation matrices using matrix logarithm and exponential.
    
    Parameters:
    A1, A2 (numpy.ndarray): 4x4 affine transformation matrices.
    alpha (float): Interpolation factor between 0 and 1.
    
    Returns:
    numpy.ndarray: 4x4 interpolated affine transformation matrix.
    """
    # Compute the matrix logarithms of the transformation matrices
    log_A1 = logm(A1)
    log_A2 = logm(A2)
    
    # Ensure the signs are consistent in the diagonal for interpolation
    for i in range(3):
        if np.sign(log_A1[i, i]) != np.sign(log_A2[i, i]):
            log_A2[i, i] = -log_A2[i, i]  # Flip to match signs

    # Interpolate in the logarithmic space
    log_A_interp = (1 - alpha) * log_A1 + alpha * log_A2
    
    # Compute the matrix exponential of the interpolated matrix
    A_interp = expm(log_A_interp)
    
    return A_interp


# This function splits a mesh into two parts by intersection with the xy plane
# def splitmesh(mesh, cap=True):
#     plane_origin = [0, 0, 0]
#     plane_normal = np.array([0, 0, 1])
    
#     # Use trimesh's slice_plane to intersect the mesh with the XY plane
#     # This function will return the intersection curve and the two resulting submeshes
#     side1 = mesh.slice_plane(plane_origin, plane_normal, cap=cap)        
#     side2 = mesh.slice_plane(plane_origin, -plane_normal, cap=cap)
    
#     return side1, side2

# This function splits a mesh into two parts by intersection with a plane
# parallel with the XY plane and skipping the middle alpha'th section
def splitmesh(mesh, alpha=0.0, cap=True):
    minz = mesh.bounds[0,2]
    maxz = mesh.bounds[1,2]
    middle = 0.5*(minz+maxz)
    lz = maxz-minz

    plane1_origin = [0, 0, middle+lz*alpha/2]
    plane2_origin = [0, 0, middle-lz*alpha/2]
    plane_normal = np.array([0, 0, 1])
    
    # Use trimesh's slice_plane to intersect the mesh with the XY plane
    # This function will return the intersection curve and the two resulting submeshes
    side1 = mesh.slice_plane(plane1_origin, plane_normal, cap=cap)        
    side2 = mesh.slice_plane(plane2_origin, -plane_normal, cap=cap)
    
    return side1, side2

"""
Computation of the squared sum of distances between corresponding vertices
in two meshes Bb and Bbt. The meshes must have identical structures. This works
as the objective function for optimization-based mesh registration.

Parameters:
B1 (trimesh.Trimesh): The first mesh.
B2 (trimesh.Trimesh): The second mesh.

Returns:
float: The squared sum of distances between corresponding vertices.
"""
def squared_sum_of_distances(B1, B2):

    # Ensure both meshes have the same number of vertices
    assert B1.vertices.shape == B2.vertices.shape, "Meshes must have the same number of vertices"

    # Compute the difference between corresponding vertices
    differences = B1.vertices - B2.vertices

    # Compute the squared distances
    squared_distances = np.sum(differences ** 2, axis=1)

    # Compute the sum of the squared distances
    squared_sum = np.sum(squared_distances)
    
    # print('Objective = ',squared_sum)

    return squared_sum

"""
An affine transformation given not ny a 4x4 matrix but by separate vectors
for scaling, rotation, shearing and translation is applied to mesh Bb. The
resulting mesh is returned. Bb is not modified.
"""
def apply_affine_transformation(Bb, scaling, rotation_vector, shearing_vector, translation):
    # Convert rotation vector to rotation matrix
    rotation_matrix = R.from_rotvec(rotation_vector).as_matrix()

    # Create shearing matrix
    shearing_matrix = np.eye(3)
    shearing_matrix[0, 1] = shearing_vector[0] * scaling[1]
    shearing_matrix[0, 2] = shearing_vector[1] * scaling[2]
    shearing_matrix[1, 2] = shearing_vector[2] * scaling[2]

    # Apply scaling, rotation, and shearing
    linear_part = np.dot(rotation_matrix, np.dot(np.diag(scaling), shearing_matrix))

    # Apply the affine transformation to the vertices of Bb
    transformed_vertices = np.dot(Bb.vertices, linear_part.T) + translation

    # Create a new mesh with the transformed vertices
    transformed_mesh = tri.Trimesh(vertices=transformed_vertices, faces=Bb.faces, process=False)

    return transformed_mesh

"""
This is just an interface function that accepts a design variable vector,
separates it into affine mapping vectors, applies it to Bb and computes returns
the squared distance between Bb and Bbt.
"""
def objective_function(params, Bb, Bbt):
    # Decompose the params into scaling, rotation_vector, shearing_vector, translation
    scaling = params[0:3]
    rotation_vector = params[3:6]
    shearing_vector = params[6:9]
    translation = params[9:12]

    # Apply the affine transformation to Bb
    transformed_Bb = apply_affine_transformation(Bb, scaling, rotation_vector, shearing_vector, translation)

    # Compute the squared sum of distances
    return squared_sum_of_distances(transformed_Bb, Bbt)

"""
This function determines the optimum affine mapping of the base mesh Bb onto the
target Bt. The returned vector contains in sequence
3 scaling factors
3 components of a rotation vector
3 components of a shearing vector
3 translation vector components
We use this representation rather than the 4x4 affine matrix to better
separate the different mapping components.
"""
def optimize_affine_transformation(Bb, Bbt):
    assert Bb.vertices.shape == Bbt.vertices.shape, "optimize_affine_transformation: Meshes must have the same number of vertices"

    # Initial guess for parameters: identity transformation
    initial_params = np.zeros(12)
    initial_params[:3] = 1.0  # Scaling factors initialized to 1

    # Define bounds if necessary (e.g., to constrain scaling or translation)
    # bounds = [(0.5, 2.0)] * 3 + [(-np.pi, np.pi)] * 3 + [(-1, 1)] * 3 + [(-5, 5)] * 3

    # Minimize the objective function
    # Set options for the optimizer, including verbose output
    options = {
        'disp': True,  # Enable verbose output
        'maxiter': 1000  # Set the maximum number of iterations (optional)
    }
    # result = minimize(objective_function, initial_params, args=(Bb, Bbt), bounds=bounds, method='L-BFGS-B', options=options)
    result = minimize(objective_function, initial_params, args=(Bb, Bbt), method='L-BFGS-B')

    return result

"""
Assign a random color to a mesh and save it
"""
def savemesh(mesh, filename):
    # Assign color and export
    mesh.visual.vertex_colors = randomcolor()
    mesh.export(filename)
    return
